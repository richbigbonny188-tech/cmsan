<?php
  defined('_VALID_XTC') or die('Direct Access to this location is not allowed.');

  ## Payone
  include (DIR_FS_EXTERNAL.'payone/modules/orders_payone.php'); 
?>