<?php
  defined('_VALID_XTC') or die('Direct Access to this location is not allowed.');

  ## Paypal
  include (DIR_FS_EXTERNAL.'paypal/modules/orders_paypal.php');
?>