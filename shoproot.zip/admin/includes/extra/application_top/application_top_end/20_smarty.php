<?php
// Smarty Template Engine 
if (!defined('TEMPLATE_ENGINE')) {
  define('TEMPLATE_ENGINE','smarty_2');
}
require (DIR_FS_EXTERNAL.'smarty/'.TEMPLATE_ENGINE.'/Smarty.class.php');
?>