<?php
/* --------------------------------------------------------------
   $Id: upload.php 11292 2018-06-15 08:55:59Z GTB $

   modified eCommerce Shopsoftware
   http://www.modified-shop.org

   Copyright (c) 2009 - 2013 [www.modified-shop.org]
   --------------------------------------------------------------
   based on:
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(upload.php,v 1.1 2003/03/22); www.oscommerce.com
   (c) 2003 nextcommerce (upload.php,v 1.7 2003/08/18); www.nextcommerce.org
   (c) 2006 XT-Commerce (upload.php 950 2005-05-14)

   Released under the GNU General Public License
   --------------------------------------------------------------*/
  
  defined( '_VALID_XTC' ) or die( 'Direct Access to this location is not allowed.' );
  include(DIR_FS_CATALOG.DIR_WS_CLASSES.'upload.php'); // modified eCommerce Shopsoftware 1.06: Using frontend class
?>