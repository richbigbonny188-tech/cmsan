<?php
/* --------------------------------------------------------------
   $Id: object_info.php 15765 2024-03-01 10:52:50Z GTB $   

   XT-Commerce - community made shopping
   http://www.xt-commerce.com

   Copyright (c) 2003 XT-Commerce
   --------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(object_info.php,v 1.5 2002/01/30); www.oscommerce.com 
   (c) 2003	 nextcommerce (object_info.php,v 1.5 2003/08/18); www.nextcommerce.org

   Released under the GNU General Public License 
   --------------------------------------------------------------*/

  defined( '_VALID_XTC' ) or die( 'Direct Access to this location is not allowed.' );
  
  #[AllowDynamicProperties]
  class objectInfo {

    // class constructor
    function __construct($object_array) {
      foreach ($object_array as $key => $value) {
        $this->$key = xtc_db_prepare_input($value);
      }
    }
    
  }
