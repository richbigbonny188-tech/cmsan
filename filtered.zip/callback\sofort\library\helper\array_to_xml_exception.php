<?php 
class ArrayToXmlException extends Exception {}
?>