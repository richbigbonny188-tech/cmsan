<?php
abstract class SofortElement {
	public abstract function render();
}
?>