<?php
class XmlToArrayException extends Exception {}
?>