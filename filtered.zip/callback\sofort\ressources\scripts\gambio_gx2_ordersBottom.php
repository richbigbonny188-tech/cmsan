<?php 
/**
 * @author SOFORT AG (integration@sofort.com)
 * @link http://www.sofort.com/
 * 
 * Copyright (c) 2012 SOFORT AG
 *
 * Released under the GNU General Public License (Version 2)
 * [http://www.gnu.org/licenses/gpl-2.0.html]
 */ ?>    </table></td>
	<!-- body_text_eof //-->
	  </tr>
	</table>
	<!-- body_eof //-->
	
	<!-- footer //-->
	<?php
	
	require (DIR_WS_INCLUDES.'footer.php');
	?>
	<!-- footer_eof //-->
	<br />
	</body>
	</html>
	<?php
	require(DIR_WS_INCLUDES . 'application_bottom.php');