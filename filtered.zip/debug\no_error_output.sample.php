<?php
/**
 * ---------- Deutsch ----------
 *
 * Mit dieser Datei können Sie die Bildschirmausgabe aller Warnungen und Fehler
 * im Shop unterdrücken. Dazu müssen Sie diese Datei von
 *  no_error_output.sample.php
 * zu
 *  no_error_output.php
 * umbenennen.
 *
 *
 * ---------- English ----------
 *
 * If you rename this file from
 *  no_error_output.sample.php
 * to
 *  no_error_output.php
 * all warning and error messages that would be displayed on screen are
 * suppressed.
 */