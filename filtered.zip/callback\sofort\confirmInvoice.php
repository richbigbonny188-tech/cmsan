<?php

// do NOT delete this file
// file exists for backward compatibility (so the old confirmInvoice.php will be overwritten)
// and to avoid errors (e.g. "file not found")